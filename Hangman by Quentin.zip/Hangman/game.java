import java.util.Arrays;
import java.util.Random;
import java.lang.Character;
import java.util.Scanner;
public class game
{
    int wrongGuesses = 0;
    int maxGuesses = 8;
    boolean[] used = new boolean[123];
    boolean[] guessed;
    String status;
    String word;
    public game()
    {
        if (Play.players() == 1)
        {
            RandomWord randWord = new RandomWord();
            word = randWord.returnWord();                
        }
        else if (Play.players() == 2)    
        {
            Scanner scan = new Scanner(System.in);
            word = scan.next();
        }
        else
            word = "ERROR";
        guessed = new boolean[word.length()];
        for(int i = 0; i < word.length(); i++)
        {
            guessed[i] = false;
        }
        letterCheck(' ');
    }
    
    public void solveWord(String x)
    {
        if (x.equals(word))
            System.out.println(word);
    }
    
    public void letterCheck(char x)
    {
        if (usedCheck(x))
            System.out.println("Enter a different letter!");
        else
        {
            for(int i = 0; i < word.length(); i++)
            {
                if(word.charAt(i) == x)
                {
                    guessed[i] = true;
                }
                else
                    wrongGuesses++;
            }
            letterUsed(x);
        }    
    }
    
    public void printWord()
    {
        for(int i = 0; i < word.length(); i++)
        {
            if(guessed[i])            
                System.out.print(word.charAt(i) + " ");
            else
                System.out.print("_ ");
        }
    }
    
    public void printUsed ()
    {
        System.out.println("");
        for (int i = 97; i < 123; i++)
        {
            if (used[i])
            {
                char a = (char)i;
                System.out.print(a + " "); 
            }
        }
    }
    
    public void letterUsed (char x)
        {
       used[x] = true;
    }

    public boolean usedCheck (char x)
    {
        if (used[x])
            return true;
        else
            return false;
    }
    
    public void newGame ()
    {
        Arrays.fill(used, false);
        for (int i = 97; i < 123; i++)
            System.out.println(used[i]);
    }
    
    public int checkGame() // returns 1 if a win, -1 if a loss, 0 if game is in proggress
    {
        int count = 0;
        for (int i = 0; i < word.length(); i++)
        {
            if (guessed[i])
                count++;
        }
        if (count == word.length())
            return 1; // win
        else if (wrongGuesses >= maxGuesses)
            return -1; // loss
        else
            return 0; // in progress (neither)
    }
    
    
}
