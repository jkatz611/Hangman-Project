import java.util.Scanner;
public class Play
{
    String word;
    static int playerNum;
    public static void main (String[] args)
    {
        game game = new game();
        Scanner scan = new Scanner(System.in);
        System.out.println("HANGMAN");
        System.out.println("by Quentin, Jonathan, Sarah, Aidan and Kayla");
        System.out.println("1 Player Mode:");
        System.out.println("Play against the computer! Every time you guess a letter right, it will fill ");
        System.out.println("in a blank. If you guess a letter wrong, a body part will appear on the hangman.");
        System.out.println("If you guess wrong 8 times, the man is hanged. All guessed letters will ");
        System.out.println("appear under the word so you don't guess the same one twice.");
        System.out.println("2 Player Mode:");
        System.out.println("Play against a friend! Same rules, but your friend choses the word instead of the computer.");
        // int playerNum = players();
        // if(playerNum==1)
        {
            // word = game.word;
        }            
        // else
        {
            System.out.println("One player turn around, while the other player types in a word.");
            // word = scan.next();
        }

        while (true)
        {
            // print gallows
            game.printWord();
            game.printUsed();
            char letter = ' ';
            String input = "";
            for(int i = 0; i < 1; i++)
            {
                System.out.println("Type a letter, then press ENTER");
                input = scan.next();
                input.toUpperCase();
                if (input.length() != 1)
                    i--;
                else if (!(input.charAt(0) > 65 && input.charAt(0) < 90) || !(input.charAt(0) > 97 && input.charAt(0) < 122))
                    i--;
                else 
                    {
                        letter = input.charAt(0);
                    }
            }
            game.letterCheck(letter);
            int check = game.checkGame();
            if (check == 1)
            {
                System.out.println("YOU WIN!");
                break;
            }
            if (check == -1)
            {
                System.out.println("GAME OVER");
                break;
            }
        }
    }
    
    public static int players()
    {
        Scanner scan = new Scanner(System.in);
        System.out.println("How many players do you want? (1 or 2)");
        playerNum = scan.nextInt();
        while(playerNum > 2 || playerNum <1)
        {
          System.out.println("How many players do you want? (1 or 2)");
          playerNum = scan.nextInt();
        }
        return playerNum;
    }
}
