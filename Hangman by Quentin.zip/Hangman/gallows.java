public class gallows
{
    // instance variables - replace the example below with your own
  
    public gallows(int switchy)
    { 
        switch (switchy) {
            case 1: gall0();
                    System.out.print("\r");
                    break;
            case 2: gall1();
                    break;
            case 3: gall2();
                    break;
            case 4: gall3();
                    break;
            case 5: gall4();
                    break;
            case 6: gall5();
                    break;
            case 7: gall6();
                    break;
            case 8: gall7();
                    break;
            case 9: gall8();
                    break;
        }
    }
  
    public void gall0()
    {
        System.out.println("\f==========|");
        System.out.println("| |       |");
        System.out.println("| |");
        System.out.println("| |");
        System.out.println("| |");
        System.out.println("| | __");
        System.out.println("| |___|");
    }
    public void gall1()
    {
        System.out.println("\f==========|");
        System.out.println("| |       |");
        System.out.println("| |       O");
        System.out.println("| |");
        System.out.println("| |");
        System.out.println("| | __");
        System.out.println("| |___|");
    }
    public void gall2()
    {
        System.out.println("\f==========|");
        System.out.println("| |       |");
        System.out.println("| |       O");
        System.out.println("| |       |");
        System.out.println("| |");
        System.out.println("| | __");
        System.out.println("| |___|");
    }
    public void gall3()
    {
        System.out.println("\f==========|");
        System.out.println("| |       |");
        System.out.println("| |       O");
        System.out.println("| |       |");
        System.out.println("| |      /");
        System.out.println("| | __");
        System.out.println("| |___|");
    }
    public void gall4()
    {
        System.out.println("\f==========|");
        System.out.println("| |       |");
        System.out.println("| |       O");
        System.out.println("| |       |");
        System.out.println("| |      / \\");
        System.out.println("| | __");
        System.out.println("| |___|");
    }
    public void gall5()
    {
        System.out.println("\f==========|");
        System.out.println("| |       |");
        System.out.println("| |      \\O");
        System.out.println("| |       |");
        System.out.println("| |      / \\");
        System.out.println("| | __");
        System.out.println("| |___|");
    }
    public void gall6()
    {
        System.out.println("\f==========|");
        System.out.println("| |       |");
        System.out.println("| |      \\O/");
        System.out.println("| |       |");
        System.out.println("| |      / \\");
        System.out.println("| | __");
        System.out.println("| |___|");
    }
    public void gall7()
    {
        System.out.println("\f==========|");
        System.out.println("| |       |");
        System.out.println("| | Help \\O/");
        System.out.println("| |       |");
        System.out.println("| |      / \\");
        System.out.println("| | __");
        System.out.println("| |___|");
    }
    public void gall8()
    {
        System.out.println("\f==========|");
        System.out.println("| |       |");
        System.out.println("| | Game  \u03C6");
        System.out.println("| | Over /|\\");
        System.out.println("| |      / \\");
        System.out.println("| | __");
        System.out.println("| |___|");
    }
}